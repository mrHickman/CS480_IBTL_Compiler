//This file is used to excercise the scanner.py
abcd efgh  ijkl 
 mnop  qrst uvwx 
// Test comment 1       
// Test Comment 2

/*
Test multiline Comment


stuff
*/

/* Multiline comment that is not multiline */ /* Followed by a multiline comment */ 

// This is line 15

x = 3+1
x = 3 + 1
x = 3  	    +     1
x=3+1
x=-3+1
x = 3-1
x = 3 - 1

/* This is a multiline followed by interest thing with no space*/ Hi 
/* Multiline *//*multiline*/ /**//**/  /*/ hello

15
15.67
frog
and
_rlakjkd877698
_lkjd78fhja
alkdjjk_9087
"HelloMyNameIsInigoMontoya"
"YouKillMyFatha"
"PrepairToTokenize"
"HaGotYa"
"bad"
"over9000"
"cheesyy"
[
<=
$

$
frong

abcd
	efgh
		ijkl
"mnop"qrst_uvwx _yz


 

91832			//int
5.87649			//float
.3325			//error

CANDY			//name
and				//keyword, binop
AND				//name
or				//keyword, binop
Or				//name
not				//keyword, unop
sin				//keyword, unop
cos				//keyword, unop
taN				//name
_hello987_876_	//name
asdl_iske9		//name
_				//name

{				//keyword, sep
[]				//keyword, sep	//keyword, sep
=				//keyword, assign
>=				//keyword, relop
==				//keyword, relop
$				//error
#				//error
/				//error
|				//error
?				//keyword, terop
++				//keyword, unop
+				//keyword, binop
--				//keyword, unop
-				//keyword, unop

"stringy"		//string
""				//string
"iesflj928_"	//error
"doggy			//error
"beep boop"		//error
"ha	HA"			//error



