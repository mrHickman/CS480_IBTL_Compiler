'''
Created on Jan 25, 2014

@author: mr_hickman

Description: 
    Holds globally defined constants
'''

BUFFERSIZE = 5