'''
Created on Feb 28, 2014

@author: mr_hickman
'''
#maybe usefull?
FloatOp = { '^'     : 'f**',
            'sin'   : 'fsin',
            'cos'   : 'fcos',
            '%'     : 'mod',
            '+'     : 'f+',
            '*'     : 'f*',
            '/'     : 'f/',  
            '-'     : 'f-'  
            }
